<?php

namespace App\Controller;

use App\Entity\Aficion;
use App\Form\Aficion1Type;
use App\Repository\AficionRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/aficion")
 */
class AficionController extends AbstractController
{
    /**
     * @Route("/", name="aficion_index", methods={"GET"})
     */
    public function index(AficionRepository $aficionRepository): Response
    {
        return $this->render('aficion/index.html.twig', [
            'aficions' => $aficionRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="aficion_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $aficion = new Aficion();
        $form = $this->createForm(Aficion1Type::class, $aficion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($aficion);
            $entityManager->flush();

            return $this->redirectToRoute('aficion_index');
        }

        return $this->render('aficion/new.html.twig', [
            'aficion' => $aficion,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="aficion_show", methods={"GET"})
     */
    public function show(Aficion $aficion): Response
    {
        return $this->render('aficion/show.html.twig', [
            'aficion' => $aficion,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="aficion_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Aficion $aficion): Response
    {
        $form = $this->createForm(Aficion1Type::class, $aficion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('aficion_index');
        }

        return $this->render('aficion/edit.html.twig', [
            'aficion' => $aficion,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="aficion_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Aficion $aficion): Response
    {
        if ($this->isCsrfTokenValid('delete'.$aficion->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($aficion);
            $entityManager->flush();
        }

        return $this->redirectToRoute('aficion_index');
    }
}
