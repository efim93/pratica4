<?php

namespace App\Controller;

use App\Entity\Aficcion;
use App\Form\AficcionType;
use App\Repository\AficcionRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/aficcion")
 */
class AficcionController extends AbstractController
{
    /**
     * @Route("/", name="aficcion_index", methods={"GET"})
     */
    public function index(AficcionRepository $aficcionRepository): Response
    {
        return $this->render('aficcion/index.html.twig', [
            'aficcions' => $aficcionRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="aficcion_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $aficcion = new Aficcion();
        $form = $this->createForm(AficcionType::class, $aficcion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($aficcion);
            $entityManager->flush();

            return $this->redirectToRoute('aficcion_index');
        }

        return $this->render('aficcion/new.html.twig', [
            'aficcion' => $aficcion,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="aficcion_show", methods={"GET"})
     */
    public function show(Aficcion $aficcion): Response
    {
        return $this->render('aficcion/show.html.twig', [
            'aficcion' => $aficcion,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="aficcion_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Aficcion $aficcion): Response
    {
        $form = $this->createForm(AficcionType::class, $aficcion);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('aficcion_index');
        }

        return $this->render('aficcion/edit.html.twig', [
            'aficcion' => $aficcion,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="aficcion_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Aficcion $aficcion): Response
    {
        if ($this->isCsrfTokenValid('delete'.$aficcion->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($aficcion);
            $entityManager->flush();
        }

        return $this->redirectToRoute('aficcion_index');
    }
}
