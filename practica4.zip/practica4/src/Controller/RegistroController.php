<?php

namespace App\Controller;

use App\Entity\Administrador;
use App\Form\AdministradorType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class RegistroController extends AbstractController
{
    /**
     * @Route("/registro", name="registro")
     */
    public function index(Request $request,UserPasswordEncoderInterface $passwordEncoder)
    {
        $administrador=new Administrador();
        $form=$this->createForm(AdministradorType::class, $administrador);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $administrador->setPassword($passwordEncoder->encodePassword($administrador,$form['password']->getData()));
            $em->persist($administrador);
            $em->flush();
            $this->addFlash('exito',$administrador::REGISTRO_EXITOSO);
            return $this->redirectToRoute('registro');
        }
        return $this->render('registro/index.html.twig', [
            'controller_name' => 'RegistroController',
            'formulario' =>$form->createView()
        ]);
    }
}
