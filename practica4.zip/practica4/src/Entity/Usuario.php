<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\UsuarioRepository")
 */
class Usuario
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $nombre;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $apellidos;

    /**
     * @ORM\Column(type="date")
     */
    private $fechaNacimiento;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Sexo", inversedBy="usuarios")
     */
    private $sexo;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Aficcion", inversedBy="usuarios")
     */
    private $aficcion;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Ciudad", inversedBy="usuarios")
     */
    private $ciudad;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $foto;

    public function __construct()
    {
        $this->aficcion = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombre(): ?string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;

        return $this;
    }

    public function getApellidos(): ?string
    {
        return $this->apellidos;
    }

    public function setApellidos(string $apellidos): self
    {
        $this->apellidos = $apellidos;

        return $this;
    }

    public function getFechaNacimiento(): ?\DateTimeInterface
    {
        return $this->fechaNacimiento;
    }

    public function setFechaNacimiento(\DateTimeInterface $fechaNacimiento): self
    {
        $this->fechaNacimiento = $fechaNacimiento;

        return $this;
    }

    public function getSexo(): ?Sexo
    {
        return $this->sexo;
    }

    public function setSexo(?Sexo $sexo): self
    {
        $this->sexo = $sexo;

        return $this;
    }

    /**
     * @return Collection|Aficcion[]
     */
    public function getAficcion(): Collection
    {
        return $this->aficcion;
    }

    public function addAficcion(Aficcion $aficcion): self
    {
        if (!$this->aficcion->contains($aficcion)) {
            $this->aficcion[] = $aficcion;
        }

        return $this;
    }

    public function removeAficcion(Aficcion $aficcion): self
    {
        if ($this->aficcion->contains($aficcion)) {
            $this->aficcion->removeElement($aficcion);
        }

        return $this;
    }

    public function getCiudad(): ?Ciudad
    {
        return $this->ciudad;
    }

    public function setCiudad(?Ciudad $ciudad): self
    {
        $this->ciudad = $ciudad;

        return $this;
    }

    public function getFoto(): ?string
    {
        return $this->foto;
    }

    public function setFoto(string $foto): self
    {
        $this->foto = $foto;

        return $this;
    }
    public function __toString(){
        return $this->nombre.$this->apellidos.$this->fechaNacimiento.$this->sexo.$this->ciudad.$this->aficcion.$this->foto;
    }
}
